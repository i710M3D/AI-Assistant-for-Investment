# AquaGrow Solutions Ltd

**Country:** IL  
**Sub-sector:** Water Management  
**Composite score:** 67.05/100  
**Priority flag:** WATCH

## Investment thesis
[NEWS-006] — 15 March 2026 AQUAGROW SOLUTIONS PARTNERS WITH OCP GROUP ON MOROCCO EXPANSION AquaGrow Solutions and OCP Group (the world's largest phosphate exporter and a major Moroccan agricultural player) have signed a strategic partnership to deploy AquaGrow's precision irrigation systems to 25,000 smallholder farms in the Souss-Massa and Gharb regions of Morocco over three years. Source: AquaGrow Solutions press release; OCP Group annual sustainability report 2025. ================================================================================ COMPANY FACTSHEET — AQUAGROW SOLUTIONS LTD ================================================================================ Document type : Company Factsheet Source : Company IR + S&P Capital IQ + News monitoring Last updated : April 2026 Analyst : Pivot & Co Research Team -------------------------------------------------------------------------------- OVERVIEW -------- AquaGrow Solutions Ltd (formerly AquaAg Technologies) is an Israeli agricultural water management company founded in 2014 and headquartered in Tel Aviv. [NEWS-010] — 16 April 2026 AQUAGROW SOLUTIONS: STRATEGIC ACQUISITION TALKS CONFIRMED AquaGrow Solutions CEO Oded Katz confirmed in an interview with The Times of Israel that the company has received "multiple expressions of interest from strategic players." He declined to name the interested parties but stated the company is "evaluating all options to maximise shareholder value." Analysts believe Valmont Industries (US) and a European agri-input distributor are the most likely acquirers. company_id: AG-004; company_name: AquaGrow Solutions Ltd; round_type: Seed; round_date: 2015-03-01; amount_eur_m: 1.4; lead_investor: OurCrowd; participating_investors: Israeli angels; post_money_valuation_eur_m: 4.0; notes: USD converted at 0.93

## Top 3 positive signals
- loss), Cosun has indicated it will consider a broader commercial rollout across its full 180,000 ha member base. Source: GreenYield Technologies press release; Cosun media centre. [NEWS-006] — 15 March 2026 AQUAGROW SOLUTIONS PARTNERS WITH OCP GROUP ON MOROCCO (agri_news_digest_q1_2026.txt, news)
- ================================================================================ COMPANY FACTSHEET — AQUAGROW SOLUTIONS LTD ================================================================================ Document type : Company Factsheet Source : Company IR + (aquagrow_solutions_ltd_factsheet.txt, factsheet)
- d AXA Climate. The Crédit Agricole LOI conversion is likely to be a key proof point in the fundraising narrative. Source: AgFunder News (unconfirmed); Dealroom.co monitoring alert. [NEWS-010] — 16 April 2026 AQUAGROW SOLUTIONS: STRATEGIC ACQUISITION TALKS CONF (agri_news_digest_q2_2026_partial.txt, news)

## Top 3 risks
- loss), Cosun has indicated it will consider a broader commercial rollout across its full 180,000 ha member base. Source: GreenYield Technologies press release; Cosun media centre. [NEWS-006] — 15 March 2026 AQUAGROW SOLUTIONS PARTNERS WITH OCP GROUP ON MOROCCO (agri_news_digest_q1_2026.txt, news)
- ================================================================================ COMPANY FACTSHEET — AQUAGROW SOLUTIONS LTD ================================================================================ Document type : Company Factsheet Source : Company IR + (aquagrow_solutions_ltd_factsheet.txt, factsheet)
- d AXA Climate. The Crédit Agricole LOI conversion is likely to be a key proof point in the fundraising narrative. Source: AgFunder News (unconfirmed); Dealroom.co monitoring alert. [NEWS-010] — 16 April 2026 AQUAGROW SOLUTIONS: STRATEGIC ACQUISITION TALKS CONF (agri_news_digest_q2_2026_partial.txt, news)

## Active alerts
- **STRATEGIC_EXIT**: M&A / strategic options detected - Monitor transaction process and valuation read-across.

## Recommended action
MONITOR 90 DAYS