# SoilSense AI Ltd

**Country:** GB  
**Sub-sector:** Soil Health & Carbon  
**Composite score:** 50.24/100  
**Priority flag:** WATCH

## Investment thesis
[NEWS-004] — 11 February 2026 SOILSENSE AI SUBMITS VERRA VCS CARBON METHODOLOGY SoilSense AI Ltd confirmed it has formally submitted its soil carbon quantification methodology to Verra for VCS validation. If approved (expected Q3 2026), the methodology would allow SoilSense to issue verified carbon credits on behalf of participating farms. We estimate the carbon credit module could add GBP 3-5M in annual revenue by 2027 if validated." Two competing methodologies are already validated (Gold Standard Soil Carbon and BCarbon), but SoilSense claims its sensor-based approach is more accurate and cost-effective. Source: SoilSense AI press release; Verra VCS programme registry. ================================================================================ COMPANY FACTSHEET — SOILSENSE AI LTD ================================================================================ Document type : Company Factsheet Source : Company pitch deck (received Jan 2026) + public filings (Companies House) Last updated : January 2026 Analyst : Pivot & Co Research Team -------------------------------------------------------------------------------- OVERVIEW -------- SoilSense AI Ltd is a UK-based startup founded in 2021, headquartered in Norwich, England.

## Top 3 positive signals
- n of 18 employees (35% of total workforce). HarvestLink's runway is estimated at under 12 months by multiple sources. Source: Handelsregister filing DE-M-2026-00234; AgFunder News. [NEWS-004] — 11 February 2026 SOILSENSE AI SUBMITS VERRA VCS CARBON METHODOLOGY (agri_news_digest_q1_2026.txt, news)
- ================================================================================ COMPANY FACTSHEET — SOILSENSE AI LTD ================================================================================ Document type : Company Factsheet Source : Company pitch deck (soilsense_ai_ltd_factsheet.txt, factsheet)
- Funding record. company_id: SS-003; company_name: SoilSense AI Ltd; round_type: Pre-seed; round_date: 2021-07-01; amount_eur_m: 0.35; lead_investor: Norfolk Angel Network; participating_investors: Founders; post_money_valuation_eur_m: 1.2 (funding_rounds.csv, funding)

## Top 3 risks
- n of 18 employees (35% of total workforce). HarvestLink's runway is estimated at under 12 months by multiple sources. Source: Handelsregister filing DE-M-2026-00234; AgFunder News. [NEWS-004] — 11 February 2026 SOILSENSE AI SUBMITS VERRA VCS CARBON METHODOLOGY (agri_news_digest_q1_2026.txt, news)
- Sustainable Agriculture Award nominee (2025) SDGs targeted : SDG 13, SDG 15, SDG 17 (Partnerships) Regulatory risk: Voluntary carbon market regulatory tightening (IOSCO guidance) STRATEGIC NOTES --------------- - Series A planned for Q2 2026, targeting GBP 6-8 (soilsense_ai_ltd_factsheet.txt, factsheet)
- ================================================================================ COMPANY FACTSHEET — SOILSENSE AI LTD ================================================================================ Document type : Company Factsheet Source : Company pitch deck (soilsense_ai_ltd_factsheet.txt, factsheet)

## Active alerts
- No active monitoring alerts.

## Recommended action
MONITOR 90 DAYS