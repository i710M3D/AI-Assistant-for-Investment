# GreenYield Technologies BV

**Country:** NL  
**Sub-sector:** Crop Protection Tech  
**Composite score:** 53.01/100  
**Priority flag:** WATCH

## Investment thesis
company_id: GY-002; company_name: GreenYield Technologies BV; round_type: Seed; round_date: 2018-09-01; amount_eur_m: 0.8; lead_investor: Rabobank Innovation Fund; post_money_valuation_eur_m: 3.5 company_id: GY-002; company_name: GreenYield Technologies BV; round_type: Series A; round_date: 2021-03-10; amount_eur_m: 5.0; lead_investor: Anterra Capital; participating_investors: Rabobank; post_money_valuation_eur_m: 18.0 ================================================================================ COMPANY FACTSHEET — GREENYIELD TECHNOLOGIES BV ================================================================================ Document type : Company Factsheet Source : Company IR + LinkedIn Intelligence + Crunchbase Last updated : February 2026 Analyst : Pivot & Co Research Team -------------------------------------------------------------------------------- OVERVIEW -------- GreenYield Technologies BV is a Dutch agtech company founded in 2017, based in Wageningen (Netherlands). company_id: GY-002; company_name: GreenYield Technologies BV; round_type: Series A Ext; round_date: 2023-11-20; amount_eur_m: 3.5; lead_investor: Anterra Capital; participating_investors: Rabobank; post_money_valuation_eur_m: 34.0; notes: Pre-Series B; Series B planned Q3 2026

## Top 3 positive signals
- Funding record. company_id: GY-002; company_name: GreenYield Technologies BV; round_type: Seed; round_date: 2018-09-01; amount_eur_m: 0.8; lead_investor: Rabobank Innovation Fund; post_money_valuation_eur_m: 3.5 (funding_rounds.csv, funding)
- Funding record. company_id: GY-002; company_name: GreenYield Technologies BV; round_type: Series A; round_date: 2021-03-10; amount_eur_m: 5.0; lead_investor: Anterra Capital; participating_investors: Rabobank; post_money_valuation_eur_m: 18.0 (funding_rounds.csv, funding)
- ================================================================================ COMPANY FACTSHEET — GREENYIELD TECHNOLOGIES BV ================================================================================ Document type : Company Factsheet Source : Company  (greenyield_technologies_bv_factsheet.txt, factsheet)

## Top 3 risks
- Funding record. company_id: GY-002; company_name: GreenYield Technologies BV; round_type: Seed; round_date: 2018-09-01; amount_eur_m: 0.8; lead_investor: Rabobank Innovation Fund; post_money_valuation_eur_m: 3.5 (funding_rounds.csv, funding)
- Funding record. company_id: GY-002; company_name: GreenYield Technologies BV; round_type: Series A; round_date: 2021-03-10; amount_eur_m: 5.0; lead_investor: Anterra Capital; participating_investors: Rabobank; post_money_valuation_eur_m: 18.0 (funding_rounds.csv, funding)
- ================================================================================ COMPANY FACTSHEET — GREENYIELD TECHNOLOGIES BV ================================================================================ Document type : Company Factsheet Source : Company  (greenyield_technologies_bv_factsheet.txt, factsheet)

## Active alerts
- **FUNDRAISE_ACTIVE**: EUR 12-15M - Track process timing and ask for data room access.

## Recommended action
MONITOR 90 DAYS