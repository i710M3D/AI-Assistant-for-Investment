# Sample RAG Answers

## Which companies have an active fundraising process? What are the expected amounts?

LLM generation failed, so I used the local extractive fallback.

Active or expected fundraising processes are: Verdant Farms SA, preparing a Series C in Q3 2026 targeting EUR 30-40M [1]; GreenYield Technologies BV, launching a Series B in September 2026 targeting EUR 12-15M [2]; SoilSense AI Ltd, Series A planned for Q2 2026 targeting GBP 6-8M [3]. BioRoot closed its EUR 12M Series A in March 2026, so it is funded rather than actively fundraising in the latest news.

Sources:
- funding_rounds.csv (funding): company_id: VF-001; company_name: Verdant Farms SA; round_type: Series B; round_date: 2024-02-28; amount_eur_m: 18.0; lead_investor: Sofinnova Partners; participating_investors: Capagro; BNP Paribas Développement; post_money_valuation_eur_m
- agri_news_digest_q2_2026_partial.txt (news): GreenYield Technologies confirmed in a LinkedIn post by CEO Pieter van den Berg that the company will formally launch its Series B fundraising process in September 2026, targeting EUR 12-15M. Van den Berg stated: "The Cosun pilot results, e
- funding_rounds.csv (funding): company_id: SS-003; company_name: SoilSense AI Ltd; round_type: Seed; round_date: 2023-05-15; amount_eur_m: 2.5; lead_investor: Breed Reply; participating_investors: Innovate UK (grant GBP 0.4M); post_money_valuation_eur_m: 11.0; notes: Ver

## What are the main regulatory risks affecting biological input companies in this portfolio?

LLM generation failed, so I used the local extractive fallback.

The main regulatory risks for biological input companies are EU FPR registration timelines, pesticide-reduction policy uncertainty, and country-level approval delays [1]. BioRoot has a specific Spanish MITERD delay of four months for RhizoBoost because additional ecotoxicology data was requested [2].

Sources:
- agri_news_digest_q1_2026.txt (news): a 35% pesticide reduction target by 2030 (down from the original 50%). partial regulatory clarity for biological inputs companies. that this "reduces the upside scenario for biocontrol companies but confirms the structural direction of trav
- agri_news_digest_q2_2026_partial.txt (news): The approval, previously expected in Q3 2026, is now anticipated for Q4 2026 at the earliest, with a risk of slipping BioRoot's CEO stated the company is "fully cooperating with the regulatory process" and does not expect the delay to mater
- bioroot_innovations_sa_factsheet.txt (factsheet): formulation design to develop next-generation biostimulants and biological soil amendments that improve crop root architecture and nutrient uptake efficiency. Its lead product, "RhizoBoost", is a microbial consortia product that increases p

## Compare the water management impact claims of AquaGrow and Verdant Farms. Are they verified?

LLM generation failed, so I used the local extractive fallback.

AquaGrow claims an average 31% reduction in irrigation water consumption and lists ISO 9001, Israel Standard 5756 for water efficiency, and a 2024 Israeli Ministry of Agriculture Water Innovation Award [1]. Verdant Farms claims an average 22% irrigation water saving and lists ISO 14001 certification [2]. The corpus supports both as stated company claims, but it does not provide direct independent validation of the water-saving percentages.

Sources:
- aquagrow_solutions_ltd_factsheet.txt (factsheet): Team : 112 FTEs (44 tech/product, 38 hardware/field ops, 30 sales/CS) Water savings per farm : Average -31% irrigation water consumption GHG emissions from water pumping: Estimated -24% reduction per hectare Certifications : ISO 9001, Israe
- verdant_farms_sa_factsheet.txt (factsheet): Carbon footprint reduction tracked per farm : Average -18% N2O emissions per hectare Water usage optimization : Average -22% irrigation water saved Certifications : ISO 14001 (2025), HVE advisory partner B-Corp application : In progress (ex
- esg_scoring_framework_agriculture_v2.1.txt (report): Climate resilience of core product/service in warming scenarios (+1.5°C, +2°C) Third-party environmental certification (ISO 14001, Rainforest Alliance, etc.) 90-100 : Demonstrable, independently verified positive environmental impact 70-89 

## Which company has the strongest revenue growth trajectory over the last 3 years?

LLM generation failed, so I used the local extractive fallback.

SoilSense AI has the highest 2023-2025 revenue CAGR because revenue grew from EUR 280k in 2023 [1] to EUR 900k in 2025 [2], although from a small base. BioRoot and Verdant also show strong trajectories, but SoilSense is the fastest by percentage growth.

Sources:
- companies_financials_2023_2025.csv (financials): company_id: SS-003; company_name: SoilSense AI Ltd; country: GB; sub_sector: Soil Health & Carbon; fy_year: 2023; revenue_eur_k: 280; revenue_growth_pct: 133; gross_margin_pct: 36; ebitda_eur_k: -980; arr_eur_k: 320; cash_eur_k: 1800; burn_
- companies_financials_2023_2025.csv (financials): company_id: SS-003; company_name: SoilSense AI Ltd; country: GB; sub_sector: Soil Health & Carbon; fy_year: 2025; revenue_eur_k: 900; revenue_growth_pct: 200; gross_margin_pct: 41; ebitda_eur_k: -1400; arr_eur_k: 1100; cash_eur_k: 2200; bur
- companies_financials_2023_2025.csv (financials): company_id: BR-006; company_name: BioRoot Innovations SA; country: BE; sub_sector: Biological Inputs; fy_year: 2023; revenue_eur_k: 340; revenue_growth_pct: 113; gross_margin_pct: 52; ebitda_eur_k: -1800; arr_eur_k: 0; cash_eur_k: 4200; bur

## What are the main technology risks mentioned across all company factsheets?

LLM generation failed, so I used the local extractive fallback.

The recurring technology risks are model accuracy and validation, data defensibility, hardware deployment complexity, integration dependence, regulatory validation for carbon or biological claims, and overengineered technology-market fit, especially blockchain traceability at HarvestLink [1][2][3].

Sources:
- harvestlink_gmbh_factsheet.txt (factsheet): Customer concentration: top 3 customers represent ~60% of SaaS ARR Blockchain traceability: buyer interest has waned; technology may be overengineered for market HarvestLink is in financial distress. The combination of revenue decline, CFO 
- soilsense_ai_ltd_factsheet.txt (factsheet): Runway limited (16 months) given Series A dependency Carbon credit module revenue highly uncertain pending Verra validation Small team size creates key-person risk SoilSense is an exciting early-stage company in a rapidly growing niche (agr
- aquagrow_solutions_ltd_factsheet.txt (factsheet): AquaGrow Solutions Ltd (formerly AquaAg Technologies) is an Israeli agricultural water management company founded in 2014 and headquartered in Tel Aviv. provides precision irrigation management systems combining AI-driven evapotranspiration

## Based on the ESG framework document, which company has the strongest ESG profile, and why?

LLM generation failed, so I used the local extractive fallback.

Based on the ESG framework logic, SoilSense AI has the strongest ESG profile because soil-carbon measurement is core to its model and its internal ESG score is highest [1][2]. AquaGrow and BioRoot are also strong, but SoilSense has the clearest direct alignment to carbon, soil health, and SDG outcomes, subject to Verra validation risk [3].

Sources:
- esg_scoring_framework_agriculture_v2.1.txt (report): Date : January 2026 This document defines the ESG scoring methodology applied by Pivot & Co when evaluating agricultural companies for investment or strategic advisory mandates. It is designed to be consistent with the EU Sustainable Financ
- soilsense_ai_ltd_factsheet.txt (factsheet): drag and short runway are concerns. The Verra validation result will be a key binary Monitor closely but wait for carbon module validation before committing. SCORING INPUTS (for AI model) revenue_growth_pct : 200
- agri_news_digest_q1_2026.txt (news): [NEWS-004] — 11 February 2026 SOILSENSE AI SUBMITS VERRA VCS CARBON METHODOLOGY SoilSense AI Ltd confirmed it has formally submitted its soil carbon quantification methodology to Verra for VCS validation. If approved (expected Q3 2026), the
