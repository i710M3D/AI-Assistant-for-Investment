# Verdant Farms SA

**Country:** FR  
**Sub-sector:** Precision Agriculture  
**Composite score:** 70.38/100  
**Priority flag:** PRIORITY

## Investment thesis
================================================================================ COMPANY FACTSHEET — VERDANT FARMS SA ================================================================================ Document type : Company Factsheet Source : Internal CRM + Company IR materials Last updated : March 2026 Analyst : Pivot & Co Research Team -------------------------------------------------------------------------------- OVERVIEW -------- Verdant Farms SA is a French precision agriculture company founded in 2019 and headquartered in Montpellier, France. company_id: VF-001; company_name: Verdant Farms SA; round_type: Seed; round_date: 2020-04-01; amount_eur_m: 1.2; lead_investor: Bpifrance; participating_investors: Business Angels; post_money_valuation_eur_m: 5.0 company_id: VF-001; company_name: Verdant Farms SA; round_type: Series A; round_date: 2022-06-15; amount_eur_m: 6.0; lead_investor: Partech Ventures; participating_investors: Capagro; post_money_valuation_eur_m: 22.0 ring Digest Source : Pivot & Co — Market Intelligence Period : January – March 2026 -------------------------------------------------------------------------------- [NEWS-001] — 14 January 2026 VERDANT FARMS SIGNS LETTER OF INTENT WITH CRÉDIT AGRICOLE Verdant Farms SA has signed a non-binding Letter of Intent (LOI) with Crédit Agricole's digital banking arm to integrate the AgroLens platform into the bank's farmer advisory services. Source: Verdant Farms press release; AgriInvestor confirmation.

## Top 3 positive signals
- ================================================================================ COMPANY FACTSHEET — VERDANT FARMS SA ================================================================================ Document type : Company Factsheet Source : Internal CRM + Com (verdant_farms_sa_factsheet.txt, factsheet)
- Funding record. company_id: VF-001; company_name: Verdant Farms SA; round_type: Seed; round_date: 2020-04-01; amount_eur_m: 1.2; lead_investor: Bpifrance; participating_investors: Business Angels; post_money_valuation_eur_m: 5.0 (funding_rounds.csv, funding)
- Funding record. company_id: VF-001; company_name: Verdant Farms SA; round_type: Series A; round_date: 2022-06-15; amount_eur_m: 6.0; lead_investor: Partech Ventures; participating_investors: Capagro; post_money_valuation_eur_m: 22.0 (funding_rounds.csv, funding)

## Top 3 risks
- ================================================================================ COMPANY FACTSHEET — VERDANT FARMS SA ================================================================================ Document type : Company Factsheet Source : Internal CRM + Com (verdant_farms_sa_factsheet.txt, factsheet)
- Funding record. company_id: VF-001; company_name: Verdant Farms SA; round_type: Seed; round_date: 2020-04-01; amount_eur_m: 1.2; lead_investor: Bpifrance; participating_investors: Business Angels; post_money_valuation_eur_m: 5.0 (funding_rounds.csv, funding)
- Funding record. company_id: VF-001; company_name: Verdant Farms SA; round_type: Series A; round_date: 2022-06-15; amount_eur_m: 6.0; lead_investor: Partech Ventures; participating_investors: Capagro; post_money_valuation_eur_m: 22.0 (funding_rounds.csv, funding)

## Active alerts
- **SCORE_PRIORITY**: Score 70.38 - Advance to IC screening and schedule expert calls.
- **FUNDRAISE_ACTIVE**: EUR 30-40M - Track process timing and ask for data room access.

## Recommended action
ADVANCE TO DD