# HarvestLink GmbH

**Country:** DE  
**Sub-sector:** Agri Supply Chain  
**Composite score:** 18.8/100  
**Priority flag:** LOW

## Investment thesis
================================================================================ COMPANY FACTSHEET — HARVESTLINK GMBH ================================================================================ Document type : Company Factsheet Source : Company IR + Handelsregister + LinkedIn Intelligence Last updated : March 2026 Analyst : Pivot & Co Research Team -------------------------------------------------------------------------------- OVERVIEW -------- HarvestLink GmbH is a German agricultural supply chain platform founded in 2018, headquartered in Munich. company_id: HL-005; company_name: HarvestLink GmbH; round_type: Series A; round_date: 2021-09-01; amount_eur_m: 8.0; lead_investor: Earlybird Venture Capital; participating_investors: BayBG; post_money_valuation_eur_m: 28.0 company_id: HL-005; company_name: HarvestLink GmbH; round_type: Seed; round_date: 2019-06-01; amount_eur_m: 1.5; lead_investor: Bayern Kapital; participating_investors: Private angels; post_money_valuation_eur_m: 6.0 [NEWS-011] — 29 April 2026 HARVESTLINK GMBH: STRATEGIC SALE MANDATE CONFIRMED HarvestLink GmbH officially confirmed it has engaged an M&A advisor (believed to be Lincoln International's Frankfurt office) to explore strategic options including a full sale, merger, or capital injection. Source: HarvestLink press release; AgFunder News; Bloomberg.

## Top 3 positive signals
- studies No third-party ESG certification SDGs targeted : SDG 2, SDG 12 (Responsible Consumption) Note: ESG claims are not independently verified STRATEGIC NOTES --------------- - Revenue declined -10% YoY due to loss of two anchor customers (moved to in-house  (harvestlink_gmbh_factsheet.txt, factsheet)
- digital tools, Agreena Differentiation : QS certification integration — rare in digital competitors SAP integration reduces friction for large feed millers TEAM ---- CEO : Klaus Weber — MBA WHU, ex-Cargill DACH operations, founded company CTO : Anna Berger — e (harvestlink_gmbh_factsheet.txt, factsheet)
- ================================================================================ COMPANY FACTSHEET — HARVESTLINK GMBH ================================================================================ Document type : Company Factsheet Source : Company IR + Hande (harvestlink_gmbh_factsheet.txt, factsheet)

## Top 3 risks
- - Management is exploring a strategic sale; mandate given to a Frankfurt-based M&A boutique - GMV growth (+8%) diverging from revenue decline suggests pricing pressure on take rate KEY RISKS --------- - Critical runway concern: 11 months without additional fun (harvestlink_gmbh_factsheet.txt, factsheet)
- overnance risk - Customer concentration: top 3 customers represent ~60% of SaaS ARR - Blockchain traceability: buyer interest has waned; technology may be overengineered for market ANALYST PRELIMINARY VIEW ------------------------ HarvestLink is in financial d (harvestlink_gmbh_factsheet.txt, factsheet)
- ================================================================================ COMPANY FACTSHEET — HARVESTLINK GMBH ================================================================================ Document type : Company Factsheet Source : Company IR + Hande (harvestlink_gmbh_factsheet.txt, factsheet)

## Active alerts
- **RUNWAY_CRITICAL**: 11.0 months - Review financing plan and downside cash bridge immediately.
- **REVENUE_DECLINE**: -10.0% - Validate churn, pricing pressure, and customer concentration before any new work.
- **ESG_ALERT**: ESG dimension 6.0/25 - Request ESG evidence pack and third-party verification plan.
- **GOVERNANCE_FLAG**: CFO departure / vacancy - Escalate to partner review and require management update.
- **STRATEGIC_EXIT**: M&A / strategic options detected - Monitor transaction process and valuation read-across.

## Recommended action
DEPRIORITISE