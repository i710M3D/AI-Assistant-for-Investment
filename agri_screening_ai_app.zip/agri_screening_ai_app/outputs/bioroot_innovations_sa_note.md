# BioRoot Innovations SA

**Country:** BE  
**Sub-sector:** Biological Inputs  
**Composite score:** 61.94/100  
**Priority flag:** WATCH

## Investment thesis
================================================================================ COMPANY FACTSHEET — BIOROOT INNOVATIONS SA ================================================================================ Document type : Company Factsheet Source : Company IR + European Patent Office + AgFunder database Last updated : April 2026 Analyst : Pivot & Co Research Team -------------------------------------------------------------------------------- OVERVIEW -------- BioRoot Innovations SA is a Belgian biotech startup founded in 2020, headquartered in Ghent (Flemish Region). company_id: BR-006; company_name: BioRoot Innovations SA; round_type: Pre-seed; round_date: 2020-11-01; amount_eur_m: 0.8; lead_investor: Ghent University Tech Transfer; participating_investors: Founders; post_money_valuation_eur_m: 3.2 company_id: BR-006; company_name: BioRoot Innovations SA; round_type: Seed; round_date: 2022-04-01; amount_eur_m: 3.5; lead_investor: Sofinnova Partners; participating_investors: Bayer AG Strategic Investments; post_money_valuation_eur_m: 14.0 [NEWS-007] — 22 March 2026 BIOROOT INNOVATIONS CONFIRMS SERIES A CLOSE AT EUR 12M BioRoot Innovations SA confirmed the close of its EUR 12M Series A round, combining a EUR 2.5M grant from the European Innovation Council (EIC Accelerator) and EUR 9.5M equity from Swifty Ventures (lead) and Bayer AG Strategic Investments (follow-on). Source: BioRoot Innovations press release; EIC Accelerator official announcement.

## Top 3 positive signals
- ================================================================================ COMPANY FACTSHEET — BIOROOT INNOVATIONS SA ================================================================================ Document type : Company Factsheet Source : Company IR + (bioroot_innovations_sa_factsheet.txt, factsheet)
- Funding record. company_id: BR-006; company_name: BioRoot Innovations SA; round_type: Pre-seed; round_date: 2020-11-01; amount_eur_m: 0.8; lead_investor: Ghent University Tech Transfer; participating_investors: Founders; post_money_valuation_eur_m: 3.2 (funding_rounds.csv, funding)
- Funding record. company_id: BR-006; company_name: BioRoot Innovations SA; round_type: Seed; round_date: 2022-04-01; amount_eur_m: 3.5; lead_investor: Sofinnova Partners; participating_investors: Bayer AG Strategic Investments; post_money_valuation_eur_m: 14.0 (funding_rounds.csv, funding)

## Top 3 risks
- profitability." Existing investors Anterra Capital and Rabobank are expected to participate in the round. Source: LinkedIn post (GreenYield Technologies official page); AgInvestor. [NEWS-013] — 20 May 2026 BIOROOT INNOVATIONS: SPANISH REGULATORY APPROVAL DELAY (agri_news_digest_q2_2026_partial.txt, news)
- ================================================================================ COMPANY FACTSHEET — BIOROOT INNOVATIONS SA ================================================================================ Document type : Company Factsheet Source : Company IR + (bioroot_innovations_sa_factsheet.txt, factsheet)
- osed, but market sources estimate the contract value at USD 8-12M over the three-year period. Source: AquaGrow Solutions press release; OCP Group annual sustainability report 2025. [NEWS-007] — 22 March 2026 BIOROOT INNOVATIONS CONFIRMS SERIES A CLOSE AT EUR 1 (agri_news_digest_q1_2026.txt, news)

## Active alerts
- No active monitoring alerts.

## Recommended action
MONITOR 90 DAYS